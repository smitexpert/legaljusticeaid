@foreach ($LawyerCourtsLink as $item)
    {{ $item->name }} <br>
@endforeach