<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Laravel Test Page</title>
</head>
<body>
    <h>This is A Test Page</h>
</body>
</html>