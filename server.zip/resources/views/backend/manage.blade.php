@extends('backend.layouts.app')
@section('content')
Hello Manager
@endsection
