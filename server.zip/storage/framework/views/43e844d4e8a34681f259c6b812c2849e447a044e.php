<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<title>
<?php if(trim($__env->yieldContent('title'))): ?>
<?php echo $__env->yieldContent('title'); ?> -
<?php endif; ?>
<?php if($SiteOptions != null): ?>
<?php echo e($SiteOptions->name); ?>

<?php else: ?>
<?php echo e("Site Name"); ?>

<?php endif; ?>

</title>


<!-- Fav Icon -->
<link rel="shortcut icon" href="<?php echo e(url('frontend')); ?>/favicon.ico">

<!-- Bootstrap -->
<link href="<?php echo e(url('frontend')); ?>/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(url('frontend')); ?>/rs-plugin/css/settings.css">
<link href="<?php echo e(url('frontend')); ?>/css/font-awesome.css" rel="stylesheet">
<link href="<?php echo e(url('frontend')); ?>/css/owl.carousel.css" rel="stylesheet">
<link href="<?php echo e(url('frontend')); ?>/css/style.css" rel="stylesheet">
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:300,300i,400,400i,700,700i" rel="stylesheet">
<?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>

<!-- Topbar Start-->
<div id="topbar" class="site-topbar">
  <div class="container">
    <div class="row">
      <div class="col-md-6 col-sm-8">
        <ul class="bar-info">
          <li><a href="tel:<?php if($SiteOptions != null): ?><?php echo e($SiteOptions->phone); ?><?php else: ?><?php echo e('000000000'); ?><?php endif; ?>"><i class="fa fa-phone"></i><?php if($SiteOptions != null): ?><?php echo e($SiteOptions->phone); ?><?php else: ?> Please Add Phone. <?php endif; ?></a></li>
          <li><a href="mailto:<?php if($SiteOptions != null): ?><?php echo e($SiteOptions->email); ?><?php else: ?><?php echo e('sm@mail.com'); ?><?php endif; ?>"><i class="fa fa-envelope-o" aria-hidden="true"></i><?php if($SiteOptions != null): ?><?php echo e($SiteOptions->email); ?><?php else: ?> Please Add Email. <?php endif; ?></a></li>
        </ul>
      </div>
      <div class="col-md-6 col-sm-4">
        <ul class="topbar-links">
          <?php if(auth()->guard()->check()): ?>
          <li><a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-user" aria-hidden="true"></i> Dashboard</a></li>
          <?php if(Auth::user()->user_role == 7): ?>
            <li><a href="<?php echo e(url('notification')); ?>"><i class="fa fa-bell" aria-hidden="true"></i></a>
              <?php if(Auth::user()->unreadNotifications()->count() > 0): ?>
                <span class="red-dot"></span>
              <?php endif; ?>
            </li>
          <?php endif; ?>
          <?php else: ?>
          <li><a href="<?php echo e(url('login')); ?>"><i class="fa fa-lock" aria-hidden="true"></i> LOGIN</a></li>
          <li><a href="<?php echo e(url('register')); ?>"><i class="fa fa-user" aria-hidden="true"></i> Register</a></li>
          <?php endif; ?>
          
        </ul>
      </div>
    </div>
  </div>
</div>
<!-- Topbar End --> 

<!-- Header Start-->
<div class="header">
  <div class="container">
    <div class="row">
      <div class="col-md-4 col-sm-3">
        <div class="logo"> <a href="<?php echo e(url("/")); ?>"><img src="<?php if($SiteOptions != null): ?><?php echo e(asset("uploaded/logo")); ?>/<?php echo e($SiteOptions->logo); ?><?php else: ?><?php echo e(asset("uploaded/logo/default-logo.jpg")); ?><?php endif; ?>" alt=""/> </a></div>
      </div>
      <div class="col-md-8 col-sm-9">
        <div class="navigationwrape">
          <div class="navbar navbar-default" role="navigation">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
            </div>
            <div class="navbar-collapse collapse">
              
              <ul class="nav navbar-nav">
                  <li> <a href="<?php echo e(url("/")); ?>" class="<?php echo e(request()->is('/') ? 'active' : ''); ?>"> Home </a></li>
                  <li> <a href="<?php echo e(url("lawyers")); ?>" class="<?php echo e(request()->is('lawyers') ? 'active' : ''); ?>"> Find A Lawyer </a></li>
                  <li> <a href="<?php echo e(url('services')); ?>"> services </a></li>
                  <li> <a href="<?php echo e(url("blogs")); ?>" class="<?php echo e(request()->is('blogs') ? 'active' : ''); ?>"> Blogs </a></li>
                  <li> <a href="<?php echo e(url("advices")); ?>" class="<?php echo e(request()->is('advices') ? 'active' : ''); ?>"> Legal Advice </a></li>
                  <li> <a href="about.html"> About </a></li>
                </ul>
            </div>
            <div class="clearfix"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Header End--> 

<?php echo $__env->yieldContent('content'); ?>

<!-- ContactWrp start -->
<div class="contact-wrap" id="contact">
  <div class="contact-left">
    <div class="container">
      <div class="row contact-info">
        <div class="col-md-6">
          <div class="headingTitle">
            <h1>Contact <span>Us</span></h1>
          </div>
          
          
          <div class="address"><?php if($SiteOptions != null): ?><span><?php echo e($SiteOptions->address); ?></span><?php else: ?><?php echo e('Please Add Address'); ?><?php endif; ?></div>
          <div class="phone"><?php if($SiteOptions != null): ?><span><?php echo e($SiteOptions->phone); ?></span><?php else: ?><?php echo e('Please Add Phone'); ?><?php endif; ?></div>
          <div class="appointment"><a href="appointment.html">Make A Appointment</a></div>
        </div>
      </div>
    </div>
    <div class="right-map">
      <div class="map">
        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d542.8010545050189!2d90.34262377978243!3d23.76464413829892!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xc39c38e66ac21541!2sHaji+Muktijuddha+Joynal+Abedin+Market!5e0!3m2!1sen!2sus!4v1566105614508!5m2!1sen!2sus" width="600" height="400" style="border:0" allowfullscreen></iframe>
      </div>
    </div>
  </div>
</div>
<!-- ContactWrp end --> 

<!-- footer start -->

<div class="footer-wrap">
  <div class="container">
    <div class="row">
      <div class="col-md-3">
        <div class="left-col">
          <div class="footer-logo"><img src="<?php if($SiteOptions != null): ?><?php echo e(asset("uploaded/logo")); ?>/<?php echo e($SiteOptions->footer_logo); ?><?php else: ?><?php echo e(asset("uploaded/logo/default-footer-logo.jpg")); ?><?php endif; ?>" alt=""></div>
          <p><?php if($SiteOptions != null): ?><?php echo e($SiteOptions->description); ?><?php else: ?> Please Add Site Descriptions. <?php endif; ?></p>
          <ul class="footer-icons">
            <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
          </ul>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="footer-heading">Quick Links</div>
        <ul class="footer-nav">
          <li><a href="index.html">Home</a></li>
          <li><a href="practice-area.html">Practice Areas</a></li>
          <li><a href="attorney.html">Attorneys</a></li>
          <li><a href="testimonial.html">Testomonials</a></li>
          <li><a href="blog.html">Blog</a></li>
          <li><a href="contact.html">Contact US</a></li>
        </ul>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="footer-heading">Practice Areas</div>
        <ul class="footer-nav">
          <?php $__currentLoopData = App\PracticeArea::limit(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(url("lawyers/practice-areas")); ?>/<?php echo e($item->slug); ?>"><?php echo e($item->name); ?></a></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </ul>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="footer-heading">Courts</div>
        <ul class="footer-nav">
            <?php $__currentLoopData = App\Court::limit(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><a href="<?php echo e(url("lawyers/courts")); ?>/<?php echo e($item->slug); ?>"><?php echo e($item->name); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    </div>
    <div class="footer-service">
      <div class="copyright">Copyright © <?php echo e(date("Y")); ?> <a href="<?php echo e(url("/")); ?>"><?php if($SiteOptions != null): ?><?php echo e($SiteOptions->name); ?><?php else: ?><?php echo e("Add Site Name"); ?><?php endif; ?></a>, All Rights Reserved | Developed By <a target="_blank" href="https://behance.net/smitexpert"><i>Sujan Molla</i></a></div>
    </div>
  </div>
</div>

<!-- footer end --> 

<!--page scroll start-->
<div class="page-scroll scrollToTop"><a href="#"><i class="fa fa-arrow-up" aria-hidden="true"></i></a></div>
<!--page scroll start-->

<!--page scroll start-->
<div class="page-scroll scrollToTop"><a href="#"><i class="fa fa-arrow-up" aria-hidden="true"></i></a></div>
<!--page scroll start-->


<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="<?php echo e(url('frontend')); ?>/js/jquery-2.1.4.min.js"></script> 
<script src="<?php echo e(url('frontend')); ?>/js/bootstrap.min.js"></script> 
<!-- Load JS siles --> 
<script src="<?php echo e(url('frontend')); ?>/js/owl.carousel.js"></script> 
<!-- SLIDER REVOLUTION SCRIPTS  --> 
<script src="<?php echo e(url('frontend')); ?>/rs-plugin/js/jquery.themepunch.tools.min.js"></script> 
<script src="<?php echo e(url('frontend')); ?>/rs-plugin/js/jquery.themepunch.revolution.min.js"></script> 
<!-- general script file --> 
<script src="<?php echo e(url('frontend')); ?>/js/script.js"></script> 

 <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html><?php /**PATH D:\LARAVEL\legaljusticeaid\resources\views/frontend/layouts/app.blade.php ENDPATH**/ ?>