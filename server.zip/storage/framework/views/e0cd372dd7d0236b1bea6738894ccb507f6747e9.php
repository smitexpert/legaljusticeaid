<?php $__env->startSection('title', "Lawyer ".$lawyer->name); ?>
<?php $__env->startSection('contents'); ?>  
<div class="col-md-8">
    <div class="row">
        <div class="col-md-12">
            <div class="attorneyWrp">
                <ul>
                    <li>
                    <div class="listWrpService">
                        <div class="row">
                        <div class="col-md-2 col-sm-3 col-xs-12">
                            <div class="listImg detailImg"><img src="<?php echo e(asset("uploaded/lawyer_images")); ?>/<?php echo e($lawyer->picture); ?>" alt="">
                            <ul class="attorney-social">
                                <?php echo LawyerRating($lawyer->id); ?>

                            </ul>
                            </div>
                        </div>
                        <div class="col-md-10 col-sm-9 col-xs-12">
                            <h3><strong><a href="<?php echo e(url("lawyers")); ?>/<?php echo e($lawyer->slug); ?>"><?php echo e($lawyer->name); ?></a></strong></h3>
                            <ul class="featureInfo">
                            <li><i class="fa fa-phone" aria-hidden="true"></i> <?php if($SiteOptions != null): ?><span><?php echo e($SiteOptions->phone); ?></span><?php else: ?><?php echo e('0123 - 456 - 780'); ?><?php endif; ?></li>
                            <li><i class="fa fa-envelope" aria-hidden="true"></i><?php if($SiteOptions != null): ?><span><?php echo e($SiteOptions->email); ?></span><?php else: ?><?php echo e('info@site.com'); ?><?php endif; ?></li>
                            </ul>
                            <p>
                                <b>Practice Areas: </b>
                                <?php $__currentLoopData = $lawyer->practiceAreas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $practiceArea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($loop->index > 0): ?>
                                        , <a href="<?php echo e(url("lawyers/practice-areas")); ?>/<?php echo e($practiceArea->slug); ?>"><?php echo e($practiceArea->name); ?></a>
                                    <?php else: ?>
                                        <a href="<?php echo e(url("lawyers/practice-areas")); ?>/<?php echo e($practiceArea->slug); ?>"><?php echo e($practiceArea->name); ?></a>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </p>
                            <ul class="attorney-btns">
                            <li><a href="#contact">Contact Now</a></li>
                            </ul>
                        </div>
                        </div>
                        <h3 class="innerhead">Summary</h3>
                        
                        <?php echo $lawyer->description; ?>

            
                        <br>
                        <ul class="edu">
                        <li>
                            <h4>Specializations:</h4>
                            <p>
                                <?php $__currentLoopData = $lawyer->specializations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($loop->index > 0): ?>
                                        , <a href="<?php echo e(url("lawyers/specializations")); ?>/<?php echo e($specialization->slug); ?>"><?php echo e($specialization->name); ?></a>
                                    <?php else: ?>
                                        <a href="<?php echo e(url("lawyers/specializations")); ?>/<?php echo e($specialization->slug); ?>"><?php echo e($specialization->name); ?></a>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </p>
                        </li>
                        <li>
                            <h4>Courts:</h4>
                            <p>
                                <?php $__currentLoopData = $lawyer->courts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $court): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($loop->index > 0): ?>
                                        , <a href="<?php echo e(url("lawyers/courts")); ?>/<?php echo e($court->slug); ?>"><?php echo e($court->name); ?></a>
                                    <?php else: ?>
                                        <a href="<?php echo e(url("lawyers/courts")); ?>/<?php echo e($court->slug); ?>"><?php echo e($court->name); ?></a>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </p>
                        </li>
                        </ul>
                    </div>
                    </li>
                </ul>
                </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <ul class="edu">
                <li>
                    <h4>Lawyer Ratings</h4>
                </li>
                <?php if(session('message')): ?>
                <li>
                    <p><?php echo e(session('message')); ?></p>
                </li>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                <li>
                    <p>Your Rating Already Submited!</p>
                </li>
                <?php endif; ?>
                <?php if(Auth::user()): ?>
                    <?php if($lawyer->userRatings->where('users_id', Auth::user()->id)->count() > 0): ?>
                        <li>
                            <h2>Your Ratings</h2>
                            <h3><?php echo e($lawyer->userRatings->where('users_id', Auth::user()->id)->first()->feedback_title); ?></h3>
                            <ul class="attorney-social">
                                <?php echo SingleRating($lawyer->userRatings->where('users_id', Auth::user()->id)->first()->ratings); ?>

                            </ul>
                            <p><?php echo e($lawyer->userRatings->where('users_id', Auth::user()->id)->first()->feedback); ?></p>
                        </li>
                    <?php else: ?>
                        <li>
                            <form action="/lawyers/<?php echo e($lawyer->slug); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="user" value="<?php echo e(Auth::user()->id); ?>">
                                <input type="hidden" name="lawyer" value="<?php echo e($lawyer->id); ?>">
                                    <h4>Rate The Lawyer</h4>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="rate">
                                                <input type="radio" id="star5" name="rate" value="5" />
                                                <label for="star5" title="text">5 stars</label>
                                                <input type="radio" id="star4" name="rate" value="4" />
                                                <label for="star4" title="text">4 stars</label>
                                                <input type="radio" id="star3" name="rate" value="3" />
                                                <label for="star3" title="text">3 stars</label>
                                                <input type="radio" id="star2" name="rate" value="2" />
                                                <label for="star2" title="text">2 stars</label>
                                                <input type="radio" id="star1" name="rate" value="1" />
                                                <label for="star1" title="text">1 star</label>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="feedback">Feedback</label>
                                                <textarea class="form-control" name="feedback" id="feedback"></textarea>
                                                <?php if ($errors->has('feedback')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('feedback'); ?>
                                                    <label class="error mt-2 text-danger"><?php echo e($message); ?></label>
                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <button type="submit" class="btn btn-success">SUBMIT</button>
                                        </div>
                                    </div>
                                    
                            </form>
                        </li>
                    <?php endif; ?>
                <?php else: ?>
                    <li>
                        <p>Please Login To Give A Feedback To this lawyer</p>
                    </li>
                <?php endif; ?>
                <?php $__empty_1 = true; $__currentLoopData = $lawyer->ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li>
                        <h3><?php echo e($rating->user->name); ?></h3>
                        <ul class="attorney-social">
                            <?php echo SingleRating($rating->ratings); ?>

                        </ul>
                        <p><?php echo e($rating->feedback); ?></p>
                    </li>
                    <div class="rating-pagination">
                        <?php echo e($lawyer->ratings->links()); ?>

                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li>
                        <p>No Rating Founds!</p>
                    </li>
                <?php endif; ?>
                
            </ul>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("frontend.layouts.lawyer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\legaljusticeaid\resources\views/frontend/lawyers/view.blade.php ENDPATH**/ ?>