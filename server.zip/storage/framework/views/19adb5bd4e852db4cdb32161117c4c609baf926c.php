<?php $__env->startSection('topbutton'); ?>
<li class="nav-item  dropdown d-none align-items-center d-lg-flex d-none">
    <a class="btn btn-sm btn-success" href="<?php echo e(url('/admin/lawyers/add')); ?>">
        <i class="mdi mdi-plus"></i> Add New Lawyer
    </a>
</li>
<li class="nav-item  dropdown d-none align-items-center d-lg-flex d-none">
    <a class="btn btn-sm btn-warning" href="<?php echo e(url('/admin/lawyers/trush')); ?>">
        <i class="mdi mdi-magnify"></i> View Trushed Lawyers
    </a>
</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <?php if(session("message")): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong>Success</strong> <?php echo e(session('message')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-body">
                    <h4>Lawyer List</h4>
                    <div class="row">
                        <div class="col-md-12">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Phone</th>
                                        <th>Experience</th>
                                        <th>Court</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $allData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->index+1); ?></td>
                                        <td><?php echo e($data->name); ?></td>
                                        <td><?php echo e($data->phone); ?></td>
                                        <td><?php echo e($data->experience); ?> Yrs</td>
                                        <td></td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="<?php echo e(url('/admin/lawyers/edit')); ?>/<?php echo e($data->id); ?>" class="btn btn-sm btn-info">Edit</a>
                                                <a href="<?php echo e(url('/admin/lawyers/property')); ?>/<?php echo e($data->id); ?>" class="btn btn-sm btn-primary">Property</a>
                                                <a href="<?php echo e(url('/admin/lawyers/delete')); ?>/<?php echo e($data->id); ?>" class="btn btn-sm btn-warning">Delete</a>
                                                <a href="<?php echo e(url('/admin/lawyers/view')); ?>/<?php echo e($data->id); ?>" class="btn btn-sm btn-success">View</a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
         $(document).ready(function() {
            $('.table').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\legaljusticeaid\resources\views/backend/lawyers.blade.php ENDPATH**/ ?>