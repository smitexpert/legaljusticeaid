<?php $__env->startSection('title', 'Find Top Rated Lawyer Of Bangladesh'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Revolution slider start -->
    
    <!-- Revolution slider end --> 
    
    <!-- Welcome start -->
    <div class="welcomeWrap">
        <div class="container">
        <div class="row">
            
            <div class="col-md-12">
                <div class="headingTitle">
                    <h1 class="text-center">Find Top Rated <span>Lawyer Of Bangladesh</span></h1>
                </div>
                <p>Find High Court Lawyer, Suprime Court Lawyer From Anywhere in Bangladesh.</p>
                <br>
                <br>
            <div class="welcome-content-box row">
                <div class="col-md-4 col-sm-4 welcome-box text-center"> <img src="<?php echo e(url('frontend')); ?>/images/icon1.png" alt="">
                <a href="<?php echo e(url("lawyers")); ?>"><h4>Find A Lawyer</h4></a>
                <p>Search for Find a Top Rated Lawyer Near You.</p>
                </div>
                <div class="col-md-4 col-sm-4 welcome-box text-center"> <img src="<?php echo e(url('frontend')); ?>/images/icon2.png" alt="">
                <a href="#"><h4>Legal Services</h4></a>
                <p>Get Expert Legal Advice Within a Few Hours.</p>
                </div>
                <div class="col-md-4 col-sm-4 welcome-box text-center"> <img src="<?php echo e(url('frontend')); ?>/images/icon3.png" alt="">
                <a href="<?php echo e(url('/blogs')); ?>"><h4>Legal Study</h4></a>
                <p>Get Expert Legal Services on Phone Right Now.</p>
                </div>
            </div>
            </div>
        </div>
        </div>
    </div>
    <!-- Welcome end --> 

    <div class="lawyer-wrap">
            <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                <div class="headingTitle">
                    <h1>OUR TOP RATED <span>LAWYERS IN BANGLADESH</span></h1>
                    
                </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="lawyer-carousel owl-theme">
                        <?php $__currentLoopData = $lawyers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <div class="court-name">
                                <?php $__currentLoopData = $item->practiceAreasFe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $practice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($practice->index < 1): ?>
                                        <p><a href=""><?php echo e($practice->name); ?></a></p>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="lawyer-info-border">
                                <div class="lawyer-area">
                                    <div class="lawyer-img">
                                        <img src="<?php echo e(asset("uploaded/lawyer_images")); ?>/<?php echo e($item->picture); ?>" alt="">
                                    </div>
                                    <div class="lawyer-info">
                                        <p class="lawyer-name">
                                            <a href="<?php echo e(url("lawyers")); ?>/<?php echo e($item->slug); ?>"><?php echo e($item->name); ?></a>
                                        </p>
                                        <ul class="experts">
                                            <?php echo LawyerRating($item->id); ?>

                                        </ul>
                                        
                                        <p class="lawyer-address">
                                            <i class="fa fa-user"></i> <?php echo e($item->experience); ?> Yrs Experience
                                        </p>
                                        <p class="lawyer-experience">
                                            <i class="fa fa-user"></i> 
                                            <?php $__currentLoopData = $item->courtsFe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $court): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($court->index < 1): ?>
                                                    <p><a href=""><?php echo e($court->name); ?></a></p>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </p>
                                    </div>
                                </div>
                                <p class="lawyer-practice-area">
                                    Practice Area: Here...
                                </p>
                            </div>
                            <div class="lawyer-category-btn">
                                <a href="#">View More Practice Name</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
            </div>
        </div>
    
    <!-- Attorney start -->
    
    <!-- Servise start -->
    <div class="service-wrap">
        <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12">
            <div class="headingTitle">
                <h1>Our <span>Service</span></h1>
                
            </div>
            </div>
        </div>
        <ul class="row serv-area">
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="col-md-3 col-sm-6">
                    <a href="<?php echo e(url('/services')); ?>/<?php echo e($service->slug); ?>">
                    <div class="service-block">
                        <h4><?php echo e($service->name); ?></h4>
                        <hr>
                        <p class="content"><?php echo e(str_limit(strip_tags($service->description), 100)); ?></p>
                    </div>
                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        </div>
    </div>
    <!-- Servise end --> 
    
    
    <!-- Practice start -->
    <div class="practice-wrap">
        <div class="container">
        <div class="headingTitle">
            <h1>Latest <span>Blog</span></h1>
            
        </div>
        <ul class="row">
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li class="col-md-3 col-sm-6">
                    <div class="practiceImg"><img src="<?php echo e(asset("/uploaded/post_thumb/")); ?>/<?php echo e($post->cover); ?>" alt="<?php echo e($post->title); ?>"></div>
                    <div class="pracInfo">
                        <h3><a href="blogs/<?php echo e($post->slug); ?>"><?php echo e($post->title); ?></a></h3>
                        
                        <div class="readmore"><a href="blogs/<?php echo e($post->slug); ?>">Read More</a></div>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                No Post Found
            <?php endif; ?>
        </ul>
        </div>
    </div>
    <!-- Practice-wrap end --> 

    <div class="practice-wrap">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="sidebar">
                                <div class="widget cases">
                                    <h5 class="widget-title">Popular Blog Post</h5>
                                    <ul class="papu-post">
                                        <?php $__currentLoopData = $popular_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <div class="media-left"> <a href="<?php echo e(url('/blogs')); ?>/<?php echo e($post->slug); ?>"><img src="<?php echo e(url('/uploaded/post_thumb')); ?>/<?php echo e($post->cover); ?>" alt=""></a> </div>
                                                <div class="media-body">
                                                <h3> <a class="media-heading" href="<?php echo e(url('/blogs')); ?>/<?php echo e($post->slug); ?>"><?php echo e($post->title); ?></a> </h3>
                                                <p><?php echo e(str_limit(strip_tags($post->article), 100)); ?></p>
                                                </div>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="sidebar">
                                <div class="widget cases">
                                    <h5 class="widget-title">Recent Question</h5>
                                    <ul class="papu-post">
                                        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                                            <li>
                                                <div class="media-body">
                                                <h3> <a class="media-heading" href="<?php echo e(url('/advice')); ?>/<?php echo e($question->id); ?>"><?php echo e($question->title); ?></a> </h3>
                                                <p><?php echo e(str_limit(strip_tags($question->details), 100)); ?></p>
                                                </div>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $('.lawyer-carousel').owlCarousel({
            loop:true,
            nav:true,
            margin: 10,
            navText: ['<span class="fa fa-chevron-left"></span>', '<span class="fa fa-chevron-right"></span>'],
            responsive:{
                0:{
                    items:1
                },
                540:{
                    items:2
                },
                960:{
                    items:3
                }
            }
        })
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\legaljusticeaid\resources\views/frontend/index.blade.php ENDPATH**/ ?>