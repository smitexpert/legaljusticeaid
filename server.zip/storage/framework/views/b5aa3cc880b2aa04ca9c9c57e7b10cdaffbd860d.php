<?php $__env->startPush('styles'); ?>
    <?php echo $__env->yieldPushContent('style'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

<div class="inner-content">
    <div class="container"> 
        
        <!-- attorney start -->
        <div class="row">
            <?php echo $__env->yieldContent('contents'); ?>
        <div class="col-md-4"> 
            <!-- Side Bar -->
            <div class="sidebar"> 
            <!-- Search -->
            <div class="widget searchside">
                <h5 class="widget-title">Search</h5>
                <div class="search">
                <form>
                    <input type="text" class="form-control" placeholder="Search">
                    <button type="submit" class="btn"><i class="fa fa-search"></i></button>
                </form>
                </div>
            </div>

            
            
            <!-- Related practice -->
            <div class="sidebar-find">
                <div class="text-center">
                    <a href="<?php echo e(url('lawyers')); ?>">
                        <div class="img-center">
                            <img src="<?php echo e(url('frontend/images')); ?>/lawyer.png" alt="" class="img-circle img-responsive">
                        </div>
                        <h1 class="fint-text">FIND A LAWYER</h1>
                    </a>
                </div>
            </div>
            </div>
        </div>
        </div>
        <!-- practice detail end --> 
        
    </div>
</div>

    
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <?php echo $__env->yieldPushContent('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\legaljusticeaid\resources\views/frontend/layouts/service.blade.php ENDPATH**/ ?>