<?php $__env->startPush('styles'); ?>
    <?php echo $__env->yieldPushContent('style'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

<div class="inner-content">
    <div class="container"> 
        
        <!-- attorney start -->
        <div class="row">
            <?php echo $__env->yieldContent('contents'); ?>
        <div class="col-md-4"> 
            <!-- Side Bar -->
            <div class="sidebar"> 
            <!-- Search -->
            <div class="widget searchside">
                <h5 class="widget-title">Search</h5>
                <div class="search">
                <form>
                    <input type="text" class="form-control" placeholder="Search">
                    <button type="submit" class="btn"><i class="fa fa-search"></i></button>
                </form>
                </div>
            </div>

            <div class="widget">
                <h5 class="widget-title">Categories</h5>
                <ul class="categories">
                    <?php $__currentLoopData = App\BlogCategory::with('posts')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(url('blogs/category')); ?>/<?php echo e($category->slug); ?>"> <?php echo e($category->name); ?> (<?php echo e($category->posts->count()); ?>)</a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            
            <!-- Related practice -->
            <div class="widget cases">
                <h5 class="widget-title">Popular Post</h5>
                <ul class="papu-post">
                    <?php $__currentLoopData = 'App\BlogPost'::withCount('comments')->orderBy('comments_count', 'desc')->limit(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <div class="media-left"> <a href="<?php echo e(url('/blogs')); ?>/<?php echo e($post->slug); ?>"><img src="<?php echo e(url('/uploaded/post_thumb')); ?>/<?php echo e($post->cover); ?>" alt=""></a> </div>
                            <div class="media-body">
                            <h3> <a class="media-heading" href="<?php echo e(url('/blogs')); ?>/<?php echo e($post->slug); ?>"><?php echo e($post->title); ?></a> </h3>
                            <p><?php echo e(str_limit(strip_tags($post->article), 30)); ?></p>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            </div>
        </div>
        </div>
        <!-- practice detail end --> 
        
    </div>
</div>

    
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <?php echo $__env->yieldPushContent('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\legaljusticeaid\resources\views/frontend/layouts/blog.blade.php ENDPATH**/ ?>