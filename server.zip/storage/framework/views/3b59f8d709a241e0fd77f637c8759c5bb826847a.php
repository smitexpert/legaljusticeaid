<?php $__env->startSection('title', 'Legal Study Blog'); ?>
<?php $__env->startSection('contents'); ?>  
<div class="col-md-8"> 
    <!-- Blog List start -->
    <div class="blogWraper">
      
        <div class="row">
            <div class="col-md-12">
              <div class="text-right">
                <a class="btn btn-success" href="<?php echo e(url('/new/advices')); ?>">Request For Advice</a>
              </div>
            </div>
          </div>
          <br>
      <ul class="blogList">
        <?php $__empty_1 = true; $__currentLoopData = $advices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <li>
            <div class="row">
                <div class="col-md-12">
                <div class="post-header">
                    <h4><a <?php if($advice->is_answerd == 1): ?>style="color: green;"<?php endif; ?> href="<?php echo e(url('/advice')); ?>/<?php echo e($advice->id); ?>"><?php echo e($advice->title); ?></a></h4>
                    <div class="postmeta">From : <a href="<?php echo e(url('/advice')); ?>/category/<?php $__currentLoopData = $advice->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($cat->slug); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>"><?php $__currentLoopData = $advice->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($cat->name); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></a></div>
                </div>
                <p><?php echo e(str_limit(strip_tags($advice->details), 100, '...')); ?></p>
                <div class="row">
                  <div class="col-xs-6">
                    <h4 class="text-primary">Response <span class="badge"><?php echo e($advice->answers->count()); ?></span></h4>
                  </div>
                  <div class="col-xs-6">
                      <div class="readmore text-right">
                        <a href="<?php echo e(url('/advice')); ?>/<?php echo e($advice->id); ?>">Read More</a></div>
                      </div>
                  </div>
                </div>
              </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h3>No Advice Question Found!</h3>
        <?php endif; ?>
         <div class="text-right">
            <?php echo e($advices->links()); ?>

         </div>
      </ul>
    </div>
    
    <!-- Pagination -->
    <div class="pagiWrap">
      <div class="row">
        <div class="col-md-12 text-center">
            
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('recentanswered'); ?>
    <!-- Related practice -->
    <div class="widget cases">
      <h5 class="widget-title">Recent Answered</h5>
      <ul class="papu-post">
        <?php $__currentLoopData = $recents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li>
              <div class="media-body">
              <h3> <a class="media-heading" href="<?php echo e($advice->id); ?>"><?php echo e($advice->title); ?></a> </h3>
              <p><?php echo e(str_limit(strip_tags($advice->details), 60)); ?></p>
              </div>
          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("frontend.layouts.advice", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\legaljusticeaid\resources\views/frontend/advice/advice.blade.php ENDPATH**/ ?>