<?php $__env->startSection('title', 'Legal Study Blog'); ?>
<?php $__env->startSection('contents'); ?>  
<div class="col-md-8"> 
    <!-- Blog List start -->
    <div class="blogWraper">
      <ul class="blogList">
          <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <li>
            <div class="row">
                <div class="col-md-5 col-sm-4">
                <div class="postimg"><img src="<?php echo e(asset("/uploaded/post_thumb/")); ?>/<?php echo e($post->cover); ?>" alt="<?php echo e($post->title); ?>">
                    <div class="date"> <?php echo e(date('d', strtotime($post->created_at))); ?> <span><?php echo e(strtoupper(date('M', strtotime($post->created_at)))); ?></span></div>
                </div>
                </div>
                <div class="col-md-7 col-sm-8">
                <div class="post-header">
                    <h4><a href="/blogs/<?php echo e($post->slug); ?>"><?php echo e($post->title); ?></a></h4>
                    <div class="postmeta">By : <span><?php echo e($post->user->name); ?> </span> Category : <span><a href="<?php echo e(url('blogs/category')); ?>/<?php $__currentLoopData = $post->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($cat->slug); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>">
                      <?php $__currentLoopData = $post->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php echo e($cat->name); ?>

                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </a></span></div>
                </div>
                <p><?php echo e(str_limit(strip_tags($post->article), 100, '...')); ?></p>
                <div class="readmore"><a href="/blogs/<?php echo e($post->slug); ?>">Read More</a></div>
                </div>
            </div>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <h1>No Post Found</h1>
          <?php endif; ?>
      </ul>
    </div>
    
    <!-- Pagination -->
    <div class="pagiWrap">
      <div class="row">
        <div class="col-md-12 text-center">
            <?php echo e($posts->links()); ?>

        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("frontend.layouts.blog", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\legaljusticeaid\resources\views/frontend/blogs/view.blade.php ENDPATH**/ ?>