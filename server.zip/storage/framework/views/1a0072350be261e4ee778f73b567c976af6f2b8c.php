<?php $__env->startSection('title', 'Legal Study Blog'); ?>
<?php $__env->startSection('contents'); ?>
        <div class="col-md-8">
			<div class="serviceWrp">
					<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if((($loop->index+1) % 2) == 1): ?>
							<div class="row">
						<?php endif; ?>
						<div class="col-md-6">
							<div class="listWrpService">
								<h3><?php echo e($category->name); ?></h3>
								<ul class="serviceName">
									<?php $__currentLoopData = $category->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li><h4><a href="<?php echo e(url('/services')); ?>/<?php echo e($service->slug); ?>"><?php echo e($service->name); ?></a></h4></li>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
							</div>
						</div>
						<?php if((($loop->index+1) % 2) == 0): ?>
							</div>
						<?php endif; ?>
						<?php if($loop->last): ?>
							<?php if((($loop->index+1)%2) == 1): ?>
								</div>
							<?php endif; ?>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("frontend.layouts.service", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\legaljusticeaid\resources\views/frontend/services/index.blade.php ENDPATH**/ ?>