<?php $__env->startSection('title', 'Category: '.$categoryPosts.' - Legal Study Blog'); ?>
<?php $__env->startSection('contents'); ?>  
<div class="col-md-8"> 
    <!-- Blog List start -->
    <div class="blogWraper">
      <ul class="blogList">
          <?php $__empty_1 = true; $__currentLoopData = $categoryPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <li>
            <div class="row">
                <div class="col-md-5 col-sm-4">
                <div class="postimg"><img src="<?php echo e(asset("/uploaded/post_thumb/")); ?>/<?php echo e($post->cover); ?>" alt="<?php echo e($post->title); ?>">
                    <div class="date"> <?php echo e(date('d', strtotime($post->created_at))); ?> <span><?php echo e(strtoupper(date('M', strtotime($post->created_at)))); ?></span></div>
                </div>
                </div>
                <div class="col-md-7 col-sm-8">
                <div class="post-header">
                    <h4><a href="/blogs/<?php echo e($post->slug); ?>"><?php echo e($post->title); ?></a></h4>
                    <div class="postmeta">By : <span><?php echo e($post->user->name); ?> </span> Category : <a href="<?php $__currentLoopData = $post->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($category->slug); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>"><?php $__currentLoopData = $post->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($category->name); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></a></div>
                </div>
                <p><?php echo e(str_limit(strip_tags($post->article), 100, '...')); ?></p>
                <div class="readmore"><a href="/blogs/<?php echo e($post->slug); ?>">Read More</a></div>
                </div>
            </div>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <h1>No Post Found</h1>
          <?php endif; ?>
      </ul>
    </div>
    
    <!-- Pagination -->
    <div class="pagiWrap">
      <div class="row">
        <div class="col-md-12 text-center">
            <?php echo e($categoryPosts->links()); ?>

        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('popularpost'); ?>
  <?php $__currentLoopData = $popularposts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <li>
      <div class="media-left"> <a href="<?php echo e(url('/blogs')); ?>/<?php echo e($post->slug); ?>"><img src="<?php echo e(url('/uploaded/post_thumb')); ?>/<?php echo e($post->cover); ?>" alt=""></a> </div>
      <div class="media-body">
      <h3> <a class="media-heading" href="<?php echo e(url('/blogs')); ?>/<?php echo e($post->slug); ?>"><?php echo e($post->title); ?></a> </h3>
      <p><?php echo e(str_limit(strip_tags($post->article), 30)); ?></p>
      </div>
  </li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("frontend.layouts.blogs.category", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\legaljusticeaid\resources\views/frontend/blogs/category.blade.php ENDPATH**/ ?>