<?php $__env->startPush('styles'); ?>
    <?php echo $__env->yieldPushContent('style'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

<div class="inner-content">
    <div class="container"> 
        
        <!-- attorney start -->
        <div class="row">
            <?php echo $__env->yieldContent('contents'); ?>
        <div class="col-md-4"> 
            <!-- Side Bar -->
            <div class="sidebar"> 
            <!-- Search -->
            <div class="widget searchside">
                <h5 class="widget-title">Search</h5>
                <div class="search">
                <form>
                    <input type="text" class="form-control" placeholder="Search">
                    <button type="submit" class="btn"><i class="fa fa-search"></i></button>
                </form>
                </div>
            </div>

            <div class="widget">
                <h5 class="widget-title">Adivce Categories</h5>
                <ul class="categories">
                    <?php $__currentLoopData = App\PracticeArea::with('advices')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(url('/advice/category')); ?>/<?php echo e($area->slug); ?>"> <?php echo e($area->name); ?> (<?php echo e($area->advices->count()); ?>)</a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            
            <?php echo $__env->yieldContent('recentanswered'); ?>
            </div>
        </div>
        </div>
        <!-- practice detail end --> 
        
    </div>
</div>

    
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <?php echo $__env->yieldPushContent('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\legaljusticeaid\resources\views/frontend/layouts/advice.blade.php ENDPATH**/ ?>