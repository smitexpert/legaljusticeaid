<?php $__env->startSection('topbutton'); ?>
<li class="nav-item  dropdown d-none align-items-center d-lg-flex d-none">
    <a class="btn btn-sm btn-success" href="<?php echo e(url('/admin/lawyers')); ?>">
        <i class="mdi mdi-arrow-left"></i> Go Back
    </a>
</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h4>Set Lawyer Property</h4>
                    <?php if(session("status")): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>Success</strong> <?php echo e(session('status')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <br>
                    <form action="<?php echo e(url("/admin/lawyers/property/")); ?>/<?php echo e($lawyerId); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="row">
                                    <div class="col-md-12">
                                        <h5>Select Courts</h5>
                                        <br>
                                        <table class="table" id="court">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Name</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $courts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $court): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td style="width: 10px"><input id="court<?php echo e($court->id); ?>" type="checkbox" name="courts[]" value="<?php echo e($court->id); ?>"></td>
                                                    <td><label for="court<?php echo e($court->id); ?>"><?php echo e($court->name); ?></label></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="row">
                                    <div class="col-md-12">
                                        <h5>Select Specialization</h5>
                                        <br>
                                        <table class="table" id="specialization">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Name</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $specializations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td style="width: 10px"><input id="specialization<?php echo e($specialization->id); ?>" type="checkbox" name="specializations[]" value="<?php echo e($specialization->id); ?>"></td>
                                                    <td><label for="specialization<?php echo e($specialization->id); ?>"><?php echo e($specialization->name); ?></label></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="row">
                                    <div class="col-md-12">
                                        <h5>Select Practice Area</h5>
                                        <br>
                                        <table class="table" id="practiceArea">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Name</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $practiceAreas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $practiceArea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td style="width: 10px;"><input id="practiceArea<?php echo e($practiceArea->id); ?>" type="checkbox" name="practiceareas[]" value="<?php echo e($practiceArea->id); ?>"></td>
                                                    <td><label for="practiceArea<?php echo e($practiceArea->id); ?>"><?php echo e($practiceArea->name); ?></label></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="float-right">
                                    <button class="btn btn-success">SUBMIT</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
         $(document).ready(function() {
            $('#practiceArea').DataTable();
            $('#specialization').DataTable();
            $('#court').DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LARAVEL\legaljusticeaid\resources\views/backend/lawyers/property.blade.php ENDPATH**/ ?>